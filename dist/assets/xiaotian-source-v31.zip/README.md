# 小天

人生归你，琐碎归我，愿你自在每一天。

面向日常生活的 AI 个人助理交互原型。当前版本为 v31。初始导入基于演示站点提交 `7ed9d183d660f72347a34d60e31c886bb64f1085`。

## 本地运行

无需安装依赖或构建。安装 Python 3 后，在项目根目录运行：

```bash
python3 -m http.server 8080 --directory dist
```

浏览器访问 http://localhost:8080 。

## 目录

- `dist/`：HTML、CSS、JavaScript 与演示附件，可直接部署到静态服务器。
- `docs/REQUIREMENTS.md`：需求文档 v0.7，作为当前需求依据。
- `docs/TASK-DETAIL.md`：任务详情布局与交互设计。
- `CHANGELOG.md`：版本改动记录。
- `docs/xiaotian-brief.html`：可离线打开的产品汇报。
- `dist/assets/`：演示附件与历史下载包。该目录内需求及设计文档属于历史版本。

## 体验范围

自然吩咐、任务回执、必要确认、结果交付、当天工作台、周期任务、主动关心、批量任务卡与详情追溯。

当前为前端 Demo：语音与任务执行使用模拟数据，状态保存在浏览器 localStorage。真实电商执行、支付、语音识别、后台调度和跨设备同步尚未接入。清除站点数据会重置本地演示状态。

## 版本管理

建议以 main 保存可运行版本，需求修改通过独立分支和 Pull Request 合入。GitHub 仓库管理与现有演示站点发布独立，推送代码不会自动发布站点。

